Highcharts.chart('Exp_NonBillable', {
    chart: {
      plotBackgroundColor: null,
      plotBorderWidth: 0,
      plotShadow: false
    },
    title: {
      text: 'Experience Wise Non Billable Engineers',
      x:+15
    },
    tooltip: {
      pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
      pie: {
        dataLabels: {
          enabled: true,
          // distance: -50,
          style: {
            fontWeight: 'bold',
            color: 'black'
          }
        },
        startAngle: -90,
        endAngle: 90,
        center: ['50%', '75%'],
        size: '150%'
      }
    },
    series: [{
      type: 'pie',
      name: 'Number of Employees',
      innerSize: '50%',
      data: [
        ['0 Years', 20],
        ['0-1 Years', 35],
        ['1-2 Years', 40],
        ['2-3 Years', 55],
        ['>3 Years', 60],
        
      ]
    }]
  });
  