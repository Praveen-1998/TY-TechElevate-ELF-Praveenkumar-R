
Highcharts.chart('Exp_Billable', {
  chart: {
    type: 'pyramid'
  },
  title: {
    text: 'Experience Wise Billable Engineers',
    x: -70
  },
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
  },
  plotOptions: {
    series: {
      dataLabels: {
        enabled: true,
        format: '<b>{point.year}</b> ({point.y:,.0f}) ',
        softConnector: true
      },
      center: ['40%', '50%'],
      width: '80%'
    }
  },
  legend: {
    enabled: false
  },
  series: [{
    name: 'Number of Employees',
    data: [
      {year :'0 years',   y :25,  
       events:{ click: function () {
            window.location.href = "./table_tech_billable.html"
  
        }
      }},
      ['0-1 years',      30],
      ['1-2 years', 35],
      ['2-3 years',     50],
      ['> 3 years',       70]
    ]
  }],

  responsive: {
    rules: [{
      condition: {
        maxWidth: 500
      },
      chartOptions: {
        plotOptions: {
          series: {
            dataLabels: {
              inside: true
            },
            center: ['50%', '50%'],
            width: '100%'
          }
        }
      }
    }]
  }
});