Highcharts.chart('Tech_NonBillable', {
    chart: {
        type: 'variablepie'
    },
    title: {
        text: 'Technology Wise Non Billable Engineers',
        x:+20
    },
    tooltip: {
        headerFormat: '',
        pointFormat: '<span style="color:{point.color}">\u25CF</span> <b> {point.name}</b><br/>' +
            ' <b>{point.y}</b><br/>' 
         
    },
    series: [{
        minPointSize: 10,
        height:'200px',
        width:'300px',
        innerSize: '20%',
        name: 'countries',
        data: [{
            name: 'Java FullStack',
            y: 500,
            events: {
                click: function () {
                    window.location.href = "./table_tech_Nonbillable.html"
      
                }
            }
        }, {
            name: 'MEAN Stack',
            y: 420,
            events: {
                click: function () {
                    window.location.href = "./table_tech_Nonbillable.html"
      
                }
            }
        }, {
            name: 'Dot net',
            y: 300,
            events: {
                click: function () {
                    window.location.href = "./table_tech_Nonbillable.html"
      
                }
            }
        }, {
            name: 'Data Science',
            y: 250,
            events: {
                click: function () {
                    window.location.href = "./table_tech_Nonbillable.html"
      
                }
            }
        }]
    }]
});