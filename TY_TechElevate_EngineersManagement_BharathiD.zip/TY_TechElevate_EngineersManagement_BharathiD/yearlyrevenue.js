
window.onload = function () {
	var chart = new CanvasJS.Chart("chartContainer1", {
		title: {
			text: 'Monthly Business Analytics'
		},
		axisY: {
			// title: "srfghd",
			lineColor: "#7F6084",
			tickColor: "#7F6084",
			labelFontColor: "#7F6084",
			titleFontColor: "#7F6084",
			suffix: "k"
		},
		toolTip: {
			shared: true
		},
		legend: {
			cursor: "pointer",
			itemclick: toggleDataSeries
		},
		data: [{
			type: "line",
			name: "Cost",
			color: "#369EAD",
			showInLegend: true,
			axisYIndex: 1,
			dataPoints: [
				{ x: new Date(2019, 00, 01), y: 85.4 },
				{ x: new Date(2019, 01, 01), y: 92.7 },
				{ x: new Date(2019, 02, 01), y: 64.9 },
				{ x: new Date(2019, 03, 01), y: 58.0 },
				{ x: new Date(2019, 04, 01), y: 63.4 },
				{ x: new Date(2019, 05, 01), y: 69.9 },
				{ x: new Date(2019, 06, 01), y: 88.9 },
				{ x: new Date(2019, 07, 01), y: 66.3 },
				{ x: new Date(2019, 08, 01), y: 82.7 },
				{ x: new Date(2019, 09, 01), y: 60.2 },
				{ x: new Date(2019, 10, 01), y: 60.2 },
				{ x: new Date(2019, 11, 01), y: 60.2 },

			]
		},
		{
			type: "line",
			name: "Revenue",
			color: "#7F6084",
			axisYType: "secondary",
			showInLegend: true,
			dataPoints: [
				{ x: new Date(2019, 00, 01), y: 42.5 },
				{ x: new Date(2019, 01, 01), y: 44.3 },
				{ x: new Date(2019, 02, 01), y: 28.7 },
				{ x: new Date(2019, 03, 01), y: 22.5 },
				{ x: new Date(2019, 04, 01), y: 25.6 },
				{ x: new Date(2019, 05, 01), y: 45.7 },
				{ x: new Date(2019, 06, 01), y: 54.6 },
				{ x: new Date(2019, 07, 01), y: 32.0 },
				{ x: new Date(2019, 08, 01), y: 43.9 },
				{ x: new Date(2019, 09, 01), y: 26.4 },
				{ x: new Date(2019, 10, 01), y: 60.2 },
				{ x: new Date(2019, 11, 01), y: 60.2 },

			]
		}]
	});
	chart.render();

	function toggleDataSeries(e) {
		if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
			e.dataSeries.visible = false;
		} else {
			e.dataSeries.visible = true;
		}
		e.chart.render();
	}

}
