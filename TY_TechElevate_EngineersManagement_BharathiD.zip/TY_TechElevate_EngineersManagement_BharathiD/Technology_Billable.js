// Build the chart
Highcharts.chart('Tech_Billable', {
    chart: {
      plotBackgroundColor: null,
      plotBorderWidth: null,
      plotShadow: false,
      type: 'pie'
    },
    title: {
      text: 'Technology Wise Billable Engineers',
      x:+20
    },
    tooltip: {
      pointFormat: '<b>{point.y}</b>'
    },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: 'pointer',
        dataLabels: {
          enabled: false
        },
        showInLegend: true
      }
    },
    series: [{
     
      colorByPoint: true,
      height:'200px',
      width:'300px',
      innerSize: '20%',
      data: [{
        name: 'Java FullStack',
        y: 25,
        events: {
          click: function () {
              window.location.href = "./table_tech_billable.html"

          }
      }
      }, {
        name: 'MEAN Stack',
        y: 15,
        events: {
          click: function () {
              window.location.href = "./table_tech_billable.html"

          }
      }
      }, {
        name: 'Dot Net',
        y: 20,
        events: {
          click: function () {
              window.location.href = "./table_tech_billable.html"

          }
      }
      }, {
        name: 'Data Science',
        y: 30,
        events: {
          click: function () {
              window.location.href = "./table_tech_billable.html"

          }
      }
      }]
    }]
  });